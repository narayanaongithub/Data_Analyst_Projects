--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "UEFA";
--
-- Name: UEFA; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "UEFA" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE "UEFA" OWNER TO postgres;

\connect "UEFA"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goals (
    goal_id character varying(10) NOT NULL,
    match_id character varying(10) NOT NULL,
    pid character varying(10) NOT NULL,
    duration integer NOT NULL,
    assist character varying(10) NOT NULL,
    goal_desc character varying(50) NOT NULL
);


ALTER TABLE public.goals OWNER TO postgres;

--
-- Name: matches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matches (
    match_id character varying(6) NOT NULL,
    season character varying(10) NOT NULL,
    event_date character varying(20) NOT NULL,
    home_team character varying(30) NOT NULL,
    away_team character varying(30) NOT NULL,
    stadium character varying(30) NOT NULL,
    home_team_score integer NOT NULL,
    away_team_score integer NOT NULL,
    penalty_shoot_out integer NOT NULL,
    attendance integer NOT NULL
);


ALTER TABLE public.matches OWNER TO postgres;

--
-- Name: players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.players (
    player_id character varying(10) NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    nationality character varying(30) NOT NULL,
    dob date NOT NULL,
    team character varying(30) NOT NULL,
    jersey_number double precision NOT NULL,
    player_position character varying(15),
    height double precision NOT NULL,
    weight double precision NOT NULL,
    foot character(1) NOT NULL
);


ALTER TABLE public.players OWNER TO postgres;

--
-- Name: stadiums; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stadiums (
    stadium_name character varying(30) NOT NULL,
    city character varying(20) NOT NULL,
    country character varying(20) NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.stadiums OWNER TO postgres;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    team_name character varying(30) NOT NULL,
    country character varying(20) NOT NULL,
    home_stadium character varying(30) NOT NULL
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goals (goal_id, match_id, pid, duration, assist, goal_desc) FROM stdin;
\.
COPY public.goals (goal_id, match_id, pid, duration, assist, goal_desc) FROM '$$PATH$$/4912.dat';

--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.matches (match_id, season, event_date, home_team, away_team, stadium, home_team_score, away_team_score, penalty_shoot_out, attendance) FROM stdin;
\.
COPY public.matches (match_id, season, event_date, home_team, away_team, stadium, home_team_score, away_team_score, penalty_shoot_out, attendance) FROM '$$PATH$$/4913.dat';

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.players (player_id, first_name, last_name, nationality, dob, team, jersey_number, player_position, height, weight, foot) FROM stdin;
\.
COPY public.players (player_id, first_name, last_name, nationality, dob, team, jersey_number, player_position, height, weight, foot) FROM '$$PATH$$/4914.dat';

--
-- Data for Name: stadiums; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stadiums (stadium_name, city, country, capacity) FROM stdin;
\.
COPY public.stadiums (stadium_name, city, country, capacity) FROM '$$PATH$$/4915.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (team_name, country, home_stadium) FROM stdin;
\.
COPY public.teams (team_name, country, home_stadium) FROM '$$PATH$$/4916.dat';

--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (goal_id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (match_id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (player_id);


--
-- Name: stadiums stadiums_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stadiums
    ADD CONSTRAINT stadiums_pkey PRIMARY KEY (stadium_name);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (team_name);


--
-- PostgreSQL database dump complete
--

